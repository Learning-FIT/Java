package advanced;

// 盤面を表すクラス
public class Board {
	private char[][] cell;	// 3×3の枠
	
	// 盤面を表示するメソッド
	public void show() {
		for (int v = 0; v < 3; v++) {
			System.out.println("+-+-+-+");
			for (int h = 0; h < 3; h++) {
				System.out.print("|" + cell[v][h]);
			}
			System.out.println("|");
		}
		System.out.println("+-+-+-+");
	}
	
	// 枠に記号を書き込むメソッド
	public boolean setCell(Player player) {
		int number = player.getNumber();
		int v = (number - 1) / 3;
		int h = (number - 1) % 3;
		
		// 書き込めたらtrueを返す
		if (cell[v][h] >= '1' && cell[v][h] <= '9') {
			cell[v][h] = player.getMark();
			return true;
		}
		
		// 書き込めないならfalseを返す
		System.out.println("そこには書き込めません！");
		return false;
	}
	
	// 勝敗を判定するメソッド
	public boolean judge(Player player) {
		// playerが勝ちならtrueを返す
		char mark = player.getMark();
		if (cell[0][0] == mark && cell[0][1] == mark & cell[0][2] == mark ||
			cell[1][0] == mark && cell[1][1] == mark & cell[1][2] == mark ||
			cell[2][0] == mark && cell[2][1] == mark & cell[2][2] == mark ||
			cell[0][0] == mark && cell[1][0] == mark & cell[2][0] == mark ||
			cell[0][1] == mark && cell[1][1] == mark & cell[2][1] == mark ||
			cell[0][2] == mark && cell[1][2] == mark & cell[2][2] == mark ||
			cell[0][0] == mark && cell[1][1] == mark & cell[2][2] == mark ||
			cell[2][0] == mark && cell[1][1] == mark & cell[0][2] == mark) {
			System.out.println("ゲーム終了：" + mark + "の勝ちです！");
			return true;
		}
		
		// 引き分けならtrueを返す
		boolean draw = true;
		for (int v = 0; v < 3 && draw; v++) {
			for (int h = 0; h < 3 && draw; h++) {
				if (cell[v][h] >= '1' && cell[v][h] <= '9') {
					draw = false;
				}
			}
		}
		if (draw) {
			System.out.println("ゲーム終了：引き分けです！");
			return true;
		}
		
		// 勝敗が確定していなければfalseを返す
		return false;
	}
	
	// コンストラクタ
	public Board() {
		// 3×3の配列を生成する
		this.cell = new char[3][3];
		
		// 枠に1～9の数字を入れる
		for (int v = 0; v < 3 ; v++) {
			for (int h = 0; h < 3; h++) {
				cell[v][h] = (char)((v * 3 + h + 1) + '0');
			}
		}
	}
}
