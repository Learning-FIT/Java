package advanced;

// プレイヤーを表す抽象クラス
public abstract class Player {
	protected char mark;	// 枠に書き込む記号（OまたはX）
	protected int number;	// 選んだ手（1～9）
	
	// 手を選ぶメソッド
	public abstract void select();
	
	// 記号を返すメソッド
	public char getMark() {
		return this.mark;
	}
	
	// 手を返すメソッド
	public int getNumber() {
		return this.number;
	}
	
	// コンストラクタ
	public Player(char mark) {
		this.mark = mark;
	}
}
