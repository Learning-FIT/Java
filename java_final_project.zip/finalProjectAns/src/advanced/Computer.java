package advanced;

// コンピュータを表すクラス
public class Computer extends Player {
	// 手を選ぶメソッド
	public void select() {
		this.number = (int)(Math.random() * 9) + 1;
		System.out.println(this.mark + "の手-->" + this.number);
	}
	
	// コンストラクタ
	public Computer(char mark) {
		super(mark);
	}
}
