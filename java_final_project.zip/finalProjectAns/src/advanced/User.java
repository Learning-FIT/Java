package advanced;

import java.util.Scanner;

// ユーザーを表すクラス
public class User extends Player {
	private Scanner scn;	// キー入力のスキャナ
	
	// 手を選ぶメソッド
	public void select() {
		boolean reEnter;	// この変数がtrueなら再入力とする
		do {
			try {
				System.out.print(this.mark + "の手-->");
				this.number = scn.nextInt();
				reEnter = false;
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
				reEnter = true;
			}
		} while (reEnter);
	}
	
	// コンストラクタ
	public User(char mark, Scanner scn) {
		super(mark);
		this.scn = scn;
	}
}
