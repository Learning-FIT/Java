package advanced;

import java.util.Scanner;

// 三目並べ（メインメソッドがあるクラス）
public class TicTacToe {

	// メインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 盤面のインスタンスを生成する
		Board board = new Board();

		// 2人のプレイヤーを格納する配列
		Player[] player = new Player[2];
		
		// ユーザーのインスタンスを生成する（記号はO）
		player[0] = new User('O', scn);
		
		// プレイヤーのインスタンスを生成する（記号はX）
		player[1] = new Computer('X');
		
		// 順番（0と1で交互に切り替える）
		int turn = 0;
		
		// 勝敗が決まるまで繰り返す
		boolean judge;
		do {
			// 現在の盤面を表示する
			board.show();
			
			// プレイヤーを交互に切り替える
			if (turn == 0) {
				turn = 1;
			}
			else {
				turn = 0;
			}
			
			// 現在のプレイヤーが手を選ぶ
			do {
				player[turn].select();
			} while (!board.setCell(player[turn]));
			
			// 勝敗を判定する
			judge = board.judge(player[turn]);
		} while (!judge);
		
		// 最終盤面を表示する
		board.show();
		
		// キー入力の終了処理
		scn.close();
	}

}
