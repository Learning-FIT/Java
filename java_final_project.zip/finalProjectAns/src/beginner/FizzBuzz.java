// 最終課題（初級）FizzBuzzの解答例
package beginner;

public class FizzBuzz {

	public static void main(String[] args) {
		// nを1～100まで1ずつ変化させる
		for (int n = 1; n <= 100; n++) {
			// 画面に表示する文字列sを空文字列で初期化する
			String s = "";

			// nが3の倍数なら文字列sに"Fizz"を連結する
			if (n % 3 == 0) {
				s += "Fizz";
			}
			
			// nが5の倍数なら文字列sに"Buzz"を連結する
			if (n % 5 == 0) {
				s += "Buzz";
			}
			
			// 文字列sが空文字列のままなら（FizzでもBuzzでもないなら）
			// 空の文字列sに数字を連結する
			if (s.equals("")) {
				s += n;
			}
			
			// 文字列sを画面に表示する
			System.out.println(s);
		}
	}

}
