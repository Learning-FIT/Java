// 最終課題（中級）Hit & Blowの解答例
package intermediate;

import java.util.Scanner;

public class HitAndBlow {
	
	// コンピュータが重複しない4桁の数字を選ぶメソッド
	public static void setComputerNumbers(int[] numbers) {
		// 0～9の数字の配列を用意する
		int[] n = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		
		// 配列の要素を100回シャッフルする
		for (int i = 1; i <= 100; i++) {
			// 配列の添字とするために0～9の乱数を2つ得る
			int idx1 = (int)(Math.random() * 10);
			int idx2 = (int)(Math.random() * 10);
			
			// n[idx1]とn[idx2]の値を交換してシャッフルする
			int temp = n[idx1];
			n[idx1] = n[idx2];
			n[idx2] = temp;
		}
		
		// 配列の先頭から4つの数字を引数numbersに格納して返す
		for (int i = 0; i < 4; i++) {
			numbers[i] = n[i];
		}
		
		return;
	}
	
	// ユーザーが4桁の数字を選ぶメソッド
	public static void setUserNumbers(int[] numbers, Scanner scn) {
		// この変数がtrueなら再入力とする
		boolean reEnter;
		
		// 4桁の数字を引数numbersに格納して返す
		do {
			try {
				// 文字列を入力する
				System.out.print("4桁の数字-->");
				String s = scn.next();
				// 1文字ずつ10進数の数字として数値に変換する
				for (int i = 0; i < 4; i++) {
					numbers[i] = Character.digit(s.charAt(i), 10);
					if (numbers[i] == -1) {
						throw new NumberFormatException("数字ではありません。");
					}
				}
				reEnter = false;
			} catch (Exception e) {
				System.out.println(e.getMessage());
				reEnter = true;
			}
		} while (reEnter);
		
		return;
	}
	
	// HitとBlowの数を表示し、正解（Hit=4）ならtrueを返すメソッド
	public static boolean check(int[] user, int[] computer) {
		int hit = 0;	// Hitの数
		int blow = 0;	// Blowの数

		// HitとBlowの数をカウントする
		for (int uIdx = 0; uIdx < 4; uIdx++) {
			for (int cIdx = 0; cIdx < 4; cIdx++) {
				// 数が同じ場合
				if (user[uIdx] == computer[cIdx]) {
					// 位置も等しければHitの数をカウントアップ
					if (uIdx == cIdx) {
						hit++;
					}
					// 位置が等しくなければBlowの数をカウントアップ
					else {
						blow++;
					}
				}
			}
		}
		
		// HitとBlowの数を表示する
		System.out.println("Hit=" + hit + ", Blow=" + blow);
		
		// 正解ならtrueを返す
		return hit == 4;
	}
	
	// メインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// コンピュータが4桁の数字を格納する配列
		int[] computerNumbers = new int[4];
		
		// ユーザーが選んだ4桁の数字を格納する配列
		int[] userNumbers = new int[4];

		// コンピュータが4つの数字を選ぶ
		HitAndBlow.setComputerNumbers(computerNumbers);

		// ユーザーのチャレンジ回数
		int count = 0;

		// ユーザーが選んだ4つの数字が正解（Hit=4）でない限り繰り返す
		boolean judge;
		do {
			// ユーザーのチャレンジ回数をカウントアップして表示する
			count++;
			System.out.println(count + "回目のチャレンジ");

			// ユーザーが4つの数字を選ぶ
			HitAndBlow.setUserNumbers(userNumbers, scn);
			
			// HitとBlowの数を表示し、正解かどうかを得る
			judge = HitAndBlow.check(userNumbers, computerNumbers);
		} while (!judge);
		
		// 正解であることを表示する
		System.out.println("正解です！");
		
		// キー入力の終了処理
		scn.close();
	}

}
