package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmployeeDAO;
import dto.Employee;

/**
 * Servlet implementation class SearchEmpServlet
 */
@WebServlet("/SearchEmpServlet")
public class SearchEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// リクエストパラメータの文字コードを設定する
		// ここにプログラムを追加してください
		request.setCharacterEncoding("UTF-8");

		// リクエストパラメータを取得する
		// ここにプログラムを追加してください
		String number = request.getParameter("number");
		if (number == null) {
			number = "";
		}
		String name = request.getParameter("name");
		if (name == null) {
			name = "";
		}
		
		// データベースを検索して結果をリクエストスコープに格納する
		// ここにプログラムを追加してください
		EmployeeDAO dao = new EmployeeDAO();
		Employee emp = new Employee(number, name);
		request.setAttribute("emp", dao.select(emp));

		// search_emp_result.jspにフォワードする
		// ここにプログラムを追加してください
		RequestDispatcher dispatcher = 
				request.getRequestDispatcher("/WEB-INF/jsp/search_emp_result.jsp");
		dispatcher.forward(request, response);
	}

}
