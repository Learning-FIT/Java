package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DateServlet
 */
@WebServlet("/DateServlet")
public class DateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 現在日時を取得する
		Date now = new Date();

		// HTTPレスポンスヘッダにHTMLであることとUTF-8であることを設定する
		response.setContentType("text/html; charset=UTF-8");

		// HTTPレスポンンスに書き込む機能を持つオブジェクトに取得する
		PrintWriter out = response.getWriter();

		// HTTPレスポンスにHTMLを書き込む（任意のHTMLを書き込む）
		out.println("<html>");
		out.println("<head>");
		out.println("<title>現在日時を取得する</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<p>現在日時は、" + now + "です。</p>");
		out.println("</body>");
		out.println("</html>");
	}

}
