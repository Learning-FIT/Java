package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BmiServlet
 */
@WebServlet("/BmiServlet")
public class BmiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// リクエストパラメータのエンコーディングを設定する
		request.setCharacterEncoding("UTF-8");

		// リクエストパラメータを取得する
		double height = Double.parseDouble(request.getParameter("height"));
		double weight = Double.parseDouble(request.getParameter("weight"));

		// BMIを求める
		height /= 100;	// cm単位の身長をm単位にする
		double bmi = weight / height / height;

		// HTTPレスポンスヘッダのコンテンツタイプにHTMLであることとUTF-8であることを設定する
		response.setContentType("text/html; charset=UTF-8");

		// HTTPレスポンンスに書き込む機能を持つオブジェクトに取得する
		PrintWriter out = response.getWriter();

		// HTTPレスポンスにHTMLを書き込む（任意のHTMLを書き込む）
		out.println("<html><head><title>BMIを求めた結果</title></head><body>");
		out.println("<p>あなたのBMIは、" + String.format("%.1f", bmi) + "です。</p>");
		out.println("</body></html>");
	}

}
