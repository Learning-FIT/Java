package basicAns;

import java.util.Scanner;

public class BodyFatnessMethod {
	// 肥満度（body fatness）を求めるメソッド
	public static double getBodyFatness(double height, double weight) {
		final int STD_BMI = 22;	// BMIの標準値
		double mHeight, stdWeight, bf;

		mHeight = height / 100;
		stdWeight = STD_BMI * mHeight * mHeight;
		bf = (weight - stdWeight) / stdWeight * 100;

		return bf;
	}
	
	// メインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 身長と体重をキー入力する
		System.out.print("身長（cm）-->");
		double height = scn.nextDouble();
		System.out.print("体重（kg）-->");
		double weight = scn.nextDouble();

		// 肥満度を求めるメソッドを呼び出す
		double bf = BodyFatnessMethod.getBodyFatness(height, weight);

		// 肥満度の値を表示する
		System.out.println("あなたの肥満度は、" + String.format("%.1f", bf) + "%です。");
		
		// キー入力の終了処理
		scn.close();
	}

}
