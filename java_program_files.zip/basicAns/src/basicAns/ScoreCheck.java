package basicAns;
import java.util.Scanner;

public class ScoreCheck {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// テストの得点をキー入力する
		System.out.print("テストの得点-->");
		int score = scn.nextInt();

		// 優、良、可、不可の判定をする
		String result;
		if (score >= 80) {
			result = "優";
		}
		else if (score >= 70) {
			result = "良";
		}
		else if (score >= 60) {
			result = "可";
		}
		else {
			result = "不可";
		}

		// 評価を表示する
		System.out.println("評価:" + result);

		// キー入力の終了処理
		scn.close();
	}

}
