package basicAns;

import java.util.Scanner;

public class Bmi2 {

	public static void main(String[] args) {
		// 定数の定義
		final double STD_BMI = 22; // 標準のBMI
		
		// 変数の宣言
		double height; // 身長（cm）
		double weight; // 体重（kg）
		double bmi; // BMI
		double stdWeight; // 標準体重（kg）

		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// データの入力
		System.out.print("身長（cm）-->");
		height = scn.nextDouble();
		System.out.print("体重（kg）-->");
		weight = scn.nextDouble();

		// データの演算
		height /= 100; // cm単位の身長をm単位にする
		bmi = weight / height / height;
		stdWeight = STD_BMI * height * height;

		// データの出力
		System.out.println("あなたのBMIは、" + String.format("%.1f", bmi) + "です。");
		System.out.println("あなたの標準体重は、" + String.format("%.1f", stdWeight) + "です。");

		// キー入力の終了処理
		scn.close();
	}

}
