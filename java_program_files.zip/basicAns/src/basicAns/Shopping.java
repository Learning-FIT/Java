package basicAns;

import java.util.Scanner;

public class Shopping {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 残金の初期値を設定する
		int money = 10000;
		
		// 残金がある限り買い物を繰り返す
		while (money > 0) {
			System.out.println("残金:" + money + "円");
			System.out.print("買い物した金額-->");
			int price = scn.nextInt();
			money -= price;
		}
		System.out.println("買い物は終了しました。");
		
		// キー入力の終了処理
		scn.close();
	}

}
