package basicAns;

import java.util.Scanner;

public class Janken {
	
	// ユーザーの手を返すメソッド
	public static int getUserHand(Scanner scn) {
		int hand = 1;
		boolean reEnter;
		do {
			try {
				System.out.println("*** グー：1, チョキ：2, パー：3 ***");
				System.out.print("ユーザーの手-->");
				String s = scn.next();
				hand = Integer.parseInt(s);
				reEnter = false;
			}
			catch (Exception e) {
				System.out.println("1, 2, 3 を選んでください。");
				reEnter = true;
			}
		} while (reEnter);
		return hand;
	}
	
	// コンピュータの手を返すメソッド
	public static int getComputerHand() {
		int hand = (int)(Math.random() * 3) + 1;
		System.out.println("コンピュータの手-->" + hand);
		return hand;
	}
	
	// じゃんけんの結果を返すメソッド
	public static String judge(int user, int computer) {
		String result;
		if (user == computer) {
			result = "あいこです。";
		} else if ((user - computer + 3) % 3 == 2) {
			result = "ユーザーの勝ちです。";
		} else {
			result = "コンピュータの勝ちです。";
		}
		return result;
	}
	
	// じゃんけんの結果を表示するメソッド
	public static void showResult(String result) {
		System.out.println("結果：" + result);
	}
	
	// 他のメソッドを連携させるメインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);
		
		// メソッドを連携させじゃんけんを行い
		// あいこの場合は、再勝負とする
		int user, computer;
		String result;
		do {
			user = Janken.getUserHand(scn);
			computer = Janken.getComputerHand();
			result = Janken.judge(user, computer);
			Janken.showResult(result);
		} while (user == computer);

		// キー入力の終了処理
		scn.close();
	}

}
