package basicAns;

import java.util.Scanner;

public class Quiz {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// クイズに正解するまで回答を繰り返す
		int answer;
		do {
			System.out.println("日本一長い川は？");
			System.out.println("1.石狩川  2.利根川  3.信濃川");
			System.out.print("回答-->");
			answer = scn.nextInt();
		} while (answer != 3);
		System.out.println("正解です。");
		
		// キー入力の終了処理
		scn.close();
	}

}
