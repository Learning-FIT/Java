package basicAns;

import java.util.Scanner;

public class AgeCheck {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 年齢をキー入力する
		System.out.print("年齢-->");
		int age = scn.nextInt();

		// 年齢をチェックする
		if (age >= 18) {
			System.out.println("成人です。");
		} 
		else {
			System.out.println("未成年です。");
		}

		// キー入力の終了処理
		scn.close();
	}

}
