package basicAns;

public class ExForArray {

	public static void main(String[] args) {
		int[] a = { 75, 67, 92, 53, 88, 74, 63, 58, 61, 82 };
		for (int data : a) {
			System.out.println(data);
		}
	}

}
