package basicAns;

public class TwoDimArray {

	public static void main(String[] args) {
		int[][] a = { { 11, 12, 13, 14, 15 }, 
				      { 21, 22, 23, 24, 25 }, 
				      { 31, 32, 33, 34, 35 } };

		for (int i = 0; i < a.length; i++) { // 変数iは行方向の添字
			for (int j = 0; j < a[i].length; j++) { // 変数jは列方向の添字
				System.out.print(a[i][j] + "\t");
			}
			System.out.println();
		}
	}

}
