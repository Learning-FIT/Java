package basicAns;

import java.util.Scanner;

public class ExceptionTest {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		try {
			// 2つの整数をキー入力する
			System.out.print("1つ目の整数-->");
			String s = scn.next(); // 文字列として入力して
			int a = Integer.parseInt(s); // 整数に変換する
			System.out.print("2つ目の整数-->");
			s = scn.next(); // 文字列として入力して
			int b = Integer.parseInt(s); // 整数に変換する

			// 除算を行う
			int ans = a / b;

			// 除算結果を表示する
			System.out.println("除算結果：" + ans);
		}
		catch (NumberFormatException e) {
			System.out.println("整数を入力してください。");
		}
		catch (ArithmeticException e) {
			System.out.println("0では除算できません。");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("プログラムを終了しました。");

			// キー入力の終了処理
			scn.close();
		}
	}

}
