package basicAns;

import java.util.Scanner;

public class LeapYearMethod {
	
	// うるう年（leap year）を判定するメソッド
	public static boolean isLeapYear(int year) {
		return year % 4 == 0 && year % 100 != 0 || year % 400 == 0;
	}
	
	// メインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 西暦をキー入力する
		System.out.print("西暦-->");
		int year = scn.nextInt();

		// 判定結果を表示する
		if (LeapYearMethod.isLeapYear(year)) {
			System.out.println("うるう年です。");
			
		}
		else {
			System.out.println("うるう年ではありません。");
		}
		
		// キー入力の終了処理
		scn.close();
	}

}
