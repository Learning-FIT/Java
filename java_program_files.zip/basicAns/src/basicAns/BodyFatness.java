package basicAns;

import java.util.Scanner;

public class BodyFatness {

	public static void main(String[] args) {
		// 定数の定義
		final double STD_BMI = 22; // 標準のBMI

		// 変数の宣言
		double height; // 身長（cm）
		double weight; // 体重（kg）
		double stdWeight; // 標準体重（kg）
		double bodyFatness; // 肥満度

		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// データの入力
		System.out.print("身長（cm）-->");
		height = scn.nextDouble();
		System.out.print("体重（kg）-->");
		weight = scn.nextDouble();

		// データの演算
		height /= 100; // cm単位の身長をm単位にする
		stdWeight = STD_BMI * height * height;
		bodyFatness = (weight - stdWeight) / stdWeight * 100;

		// データの出力
		System.out.println("あなたの肥満度は、" + String.format("%.1f", bodyFatness) + "%です。");

		// キー入力の終了処理
		scn.close();
	}

}
