package basicAns;

import java.util.Scanner;

public class AdultMethod {

	// 成人（adult）を判定するメソッド
	public static boolean isAdult(int age) {
		final int ADLUT_AGE = 18;
		// ageがマイナスなら例外を通知する
		if (age < 0) {
			throw new IllegalArgumentException("年齢がマイナスです。");
		} else {
			return age >= ADLUT_AGE;
		}
	}

	// メインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// この変数がtrueなら再入力とする
		boolean reEnter;

		do {
			try {
				// 年齢をキー入力する
				System.out.print("年齢-->");
				int age = scn.nextInt();

				// 判定結果を表示する
				if (AdultMethod.isAdult(age)) {
					System.out.println("成人です。");
				}
				else {
					System.out.println("未成年です。");
				}

				// 再入力にしない
				reEnter = false;
			}
			catch (Exception e) {
				// 例外のメッセージを表示する。
				System.out.println(e.getMessage());

				// 再入力にする
				reEnter = true;
			}
		} while (reEnter);
		
		// キー入力の終了処理
		scn.close();
	}

}
