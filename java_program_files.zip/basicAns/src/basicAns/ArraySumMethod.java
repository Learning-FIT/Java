package basicAns;

public class ArraySumMethod {

	// 配列の合計値を求めるを行うメソッド
	public static int arraySum(int[] a) {
		int sum = 0; 	// 合計値を初期化する

		for (int i = 0; i < a.length; i++) {
			sum += a[i];	// 要素の値を集計する
		}

		return sum; 	// 合計値を返す
	}

	// メインメソッド
	public static void main(String[] args) {
		// 初期値を持つ要素数10個の配列を宣言する
		int[] a = { 75, 67, 92, 53, 88, 74, 63, 58, 61, 82 };

		// 配列の合計値を表示する
		System.out.println("合計値：" + ArraySumMethod.arraySum(a));
	}

}
