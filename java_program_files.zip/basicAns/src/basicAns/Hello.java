package basicAns;

public class Hello {

	public static void main(String[] args) {
		// エラーを確認する
		// System.out.println("hello, world"); の末尾のセミコロンを書き忘れる
		// Systemの先頭を小文字にしてsystemと記述する
		// println("hello, world") の閉じカッコ ) を忘れる
		System.out.println("hello, world");

		// 「古池や」「蛙飛び込む」「水の音」という俳句を表示する
		System.out.println("古池や");
		System.out.println("蛙飛び込む");
		System.out.println("水の音");
	}

}
