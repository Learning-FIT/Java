package basicAns;

import java.util.Scanner;

public class TVSwitch {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// TVチャンネル番号をキー入力する
		System.out.print("TVチャンネル番号（1～8）-->");
		int channel = scn.nextInt();

		// TVチャンネル番号に対応する放送局を得る
		String station;
		switch (channel) {
		case 1:
			station = "NHK総合";
			break;
		case 2:
			station = "NHK Eテレ";
			break;
		case 4:
			station = "日本テレビ";
			break;
		case 5:
			station = "テレビ朝日";
			break;
		case 6:
			station = "TBS";
			break;
		case 7:
			station = "テレビ東京";
			break;
		case 8:
			station = "フジテレビ";
			break;
		default:
			station = "放送局が割り当てられていません。";
			break;
		}

		// 放送局を表示する
		System.out.println(station);

		// キー入力の終了処理
		scn.close();
	}

}
