package basicAns;

import java.util.Scanner;

public class SysScan {

	public static void main(String[] args) {
		// 変数を宣言する
		int a;
		double b;
		String c;
		
		// Scannerクラスのインスタンスを生成してscnという名前をつける
		// キー入力の準備処理をする
		Scanner scn = new Scanner(System.in);
		
		// 整数データを入力する
		System.out.print("整数データ-->");
		a = scn.nextInt();
		
		// 小数点数データを入力する
		System.out.print("小数点数データ-->");
		b = scn.nextDouble();

		// 文字列データを入力する
		System.out.print("文字列データ-->");
		c = scn.next();

		// 入力されたデータを画面に表示する
		System.out.println();
		System.out.println("整数データは、" + a + "です。");
		System.out.println("小数点数データは、" + b + "です。");
		System.out.println("文字列データは、" + c + "です。");

		// キー入力の終了処理をする
		scn.close();
	}

}
