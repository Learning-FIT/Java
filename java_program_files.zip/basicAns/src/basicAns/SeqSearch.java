package basicAns;

import java.util.Scanner;

public class SeqSearch {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);
		
		// 初期値を持つ要素数10個の配列を宣言する
		int[] a = { 75, 67, 92, 53, 88, 74, 63, 58, 61, 82 };
		
		// 探索する値をキー入力する
		System.out.print("探索する値-->");		
		int x = scn.nextInt();
		
		// 探索結果を格納する変数に初期値を設定する
		String result = "見つかりません。";
		
		// for文を使って配列の要素を順に取り出す
		for (int i = 0; i < a.length; i++) {
			// 目的の値が見つかったら繰り返しを途中終了する
			if (a[i] == x) {
				result = i + "番目に見つかりました。";
				break;
			}
		}

		// 探索結果を表示する
		System.out.println(result);
		
		// キー入力の終了処理
		scn.close();
	}

}
