package basicAns;

import java.util.Scanner;

public class AbsValue {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 整数をキー入力する
		System.out.print("整数-->");
		int n = scn.nextInt();

		// マイナスならプラスに変換する
		if (n < 0) {
			n = -n;
		}

		// 絶対値を表示する
		System.out.println("絶対値は、" + n + "です。");

		// キー入力の終了処理
		scn.close();
	}

}
