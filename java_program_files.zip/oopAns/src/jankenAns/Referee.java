package jankenAns;

// 審判を表すクラス
public class Referee {
	// 判定結果を保持するフィールド
	private String result;

	// 勝敗を判定するメソッド
	public void judge(Player p1, Player p2) {
		int h1 = p1.getHand();
		int h2 = p2.getHand();

		if (h1 == h2) {
			this.result = "あいこです。";
		}
		else if ((h1 - h2 + 3) % 3 == 2) {
			this.result = p1.getName() + "の勝ちです。";
		}
		else {
			this.result = p2.getName() + "の勝ちです。";
		}
	}

	// あいこかどうかを返すメソッド
	public boolean isDraw() {
		return this.result.equals("あいこです。");
	}

	// 判定結果を表示するメソッド
	public void showResult() {
		System.out.println("結果：" + this.result);
	}

	// コンストラクタ
	public Referee() {
		this.result = "";
	}
}
