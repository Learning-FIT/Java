package jankenAns;

// コンピュータを表すクラス
public class Computer extends Player {
	// 手を選ぶ抽象メソッドの実装
	public void setHand() {
		this.hand = (int) (Math.random() * 3) + 1;
		System.out.println("コンピュータの手-->" + this.hand);
	}

	// コンストラクタ
	public Computer(String name, int hand) {
		super(name, hand);
	}
}
