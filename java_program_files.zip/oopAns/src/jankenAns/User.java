package jankenAns;

import java.util.Scanner;

// ユーザーを表すクラス
public class User extends Player {
	// mainメソッドから渡されたScannerの参照を保持するフィールド
	private Scanner scn;

	// 手を選ぶ抽象メソッドの実装
	public void setHand() {
		int hand = 1;
		boolean reEnter;
		do {
			try {
				System.out.println("*** グー：1, チョキ：2, パー：3 ***");
				System.out.print(this.name + "の手-->");
				String s = this.scn.next();
				hand = Integer.parseInt(s);
				reEnter = false;
			}
			catch (Exception e) {
				System.out.println("1, 2, 3 を選んでください。");
				reEnter = true;
			}
		} while (reEnter);
		this.hand = hand;
	}

	// コンストラクタ
	public User(String name, int hand, Scanner scn) {
		super(name, hand);
		this.scn = scn;
	}
}
