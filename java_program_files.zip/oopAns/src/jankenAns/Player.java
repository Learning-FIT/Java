package jankenAns;

// プレイヤーを表す抽象クラス
public abstract class Player {
	// 名前と手を保持するフィールド
	protected String name;
	protected int hand;

	// 名前を返すメソッド
	public String getName() {
		return this.name;
	}

	// 手を選ぶ抽象メソッド
	public abstract void setHand();

	// 手を返すメソッド
	public int getHand() {
		return this.hand;
	}

	// コンストラクタ
	public Player(String name, int hand) {
		this.name = name;
		this.hand = hand;
	}
}
