package jankenAns;

import java.util.Scanner;

// メインメソッドを持つクラス
public class Janken {
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 2人のプレイヤーと審判のインスタンスを生成する
		Player p1 = new User("ユーザー", 1, scn);
		Player p2 = new Computer("コンピュータ", 1);
		Referee r = new Referee();

		// あいこである限りじゃんけんを繰り返す
		do {
			p1.setHand();
			p2.setHand();
			r.judge(p1, p2);
			r.showResult();
		} while (r.isDraw());

		// キー入力の終了処理
		scn.close();
	}
}
