package oopAns;

// 楽器のインターフェイス
public interface Instrument {
    // 音を奏でるメソッド
	void play();
}
