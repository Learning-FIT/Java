package oopAns;

// Trapezoidクラスをテストするクラス
public class TrapezoidTest {
	
	public static void main(String[] args) {
		// 引数があるコンストラクタでTrapezoidTestクラスのインスタンスを生成する
		Trapezoid t1 = new Trapezoid(10, 20, 30);

		// 面積を表示する
		System.out.println(t1.getArea());

		// 引数がないコンストラクタでTrapezoidTestクラスのインスタンスを生成する
		Trapezoid t2 = new Trapezoid();

		// 面積を表示する
		System.out.println(t2.getArea());
	}

}
