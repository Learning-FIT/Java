package oopAns;

// 円を表すクラス
public class Circle {
	// 半径を保持するフィールド
	private double radius;
	
	// 面積を返すメソッド
	public double getArea() {
		return this.radius * this.radius * Math.PI;
	}
	
	// 拡大するメソッド
	public void zoom(double rate) {
		this.radius *= rate;
	}
	
	// コンストラクタ
	public Circle(double radius) {
		this.radius = radius;
	}
}
