package oopAns;

// 社員を表すクラス
public class Employee {
	// 氏名、時給、時間を保持するフィールド
	protected String name;
	protected int wage;
	protected int hour;
	
	// 氏名を返すメソッド
	public String getName() {
		return this.name;
	}
	
	// 時間を追加するメソッド
	public void addHour(int hour) {
		this.hour += hour;
	}

	// 給与を返すメソッド
	public int getSalary() {
		return this.wage * this.hour;
	}
	
	// コンストラクタ
	public Employee(String name, int wage, int hour) {
		this.name = name;
		this.wage = wage;
		this.hour = hour;
	}
}
