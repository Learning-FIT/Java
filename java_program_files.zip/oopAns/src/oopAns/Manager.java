package oopAns;

// 課長を表すクラス
public class Manager extends Employee{
	// 役職手当を保持するフィールド
	protected int allowance;
	
	// 給与を返すメソッド（オーバーライド）
	public int getSalary() {
		return super.getSalary() + this.allowance;
	}

	// コンストラクタ
	public Manager(String name, int wage, int hour, int allowance) {
		super(name, wage, hour);
		this.allowance = allowance;
	}
}
