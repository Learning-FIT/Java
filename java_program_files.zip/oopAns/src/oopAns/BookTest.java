package oopAns;

// Bookクラスをテストするクラス
public class BookTest {
	// フィールドの値を表示するメソッド
	public static void showBook(Book bk) {
		// ゲッタでフィールドの値を読み出す
		System.out.println("書名：" + bk.getTitle() + ", 著者：" + bk.getAuthor()
			+ ", 出版社：" + bk.getPublisher() + ", 価格：" + bk.getPrice() + "円");
	}
	
	public static void main(String[] args) {
		// Bookクラスのインスタンスを生成する
		Book bk = new Book("Javaの絵本", "（株）アンク", "翔泳社", 1738);

		// フィールドの値を表示する
		BookTest.showBook(bk);
		
		// セッタでフィールドに値を書き込む
		bk.setTitle("Java1年生");
		bk.setAuthor("森 巧尚");
		bk.setPublisher("翔泳社");
		bk.setPrice(2178);

		// フィールドの値を表示する
		BookTest.showBook(bk);
	}

}
