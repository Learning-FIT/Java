package oopAns;

// 銀行口座を表すクラス
public class BankAccount {
	private String bankName;	// 銀行名
	private String number;		// 番号
	private String holder;		// 名義
	private int balance;		// 残高

	// 銀行名のゲッタ（リードオンリー）
	public String getBankName() {
		return bankName;
	}
	
	// 番号のゲッタ（リードオンリー）
	public String getNumber() {
		return number;
	}
	
	// 名義のゲッタ（リードオンリー）
	public String getHolder() {
		return holder;
	}
	
	// 残高のゲッタ
	public int getBalance() {
		return balance;
	}
	
	// 残高のセッタ
	public void setBalance(int balance) {
		if (balance >= 0) {
			this.balance = balance;
		}
		else {
			System.out.println("残高に書き込みできません。");
		}
	}

	// コンストラクタ
	public BankAccount(String bankName, String number, String holder, int balance) {
		super();
		this.bankName = bankName;
		this.number = number;
		this.holder = holder;
		this.balance = balance;
	}

}
