package oopAns;

// Animalクラス、Dogクラス、Catクラスをテストするクラス
public class AnimalTest {

	public static void main(String[] args) {
		// 動物の入れ物を用意する
		Animal[] a = new Animal[5];
		
		// 犬と猫を入れる
		a[0] = new Dog();
		a[1] = new Cat();
		a[2] = new Dog();
		a[3] = new Dog();
		a[4] = new Cat();

		// 動物を順番に鳴かせる
		for (int i = 0; i < a.length; i++) {
			a[i].speak();
		}
	}

}
