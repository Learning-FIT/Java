package oopAns;

import java.util.Scanner;

public class ClsInst {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 数値をキー入力する
		System.out.print("数値-->");
		double a = scn.nextDouble();
		
		// 平方根を求める
		double r = Math.sqrt(a);

		// 平方根を表示する
		System.out.println("平方根："+ r);
		
		// キー入力の終了処理
		scn.close();
	}

}
