package oopAns;

// ピアノを表すクラス
public class Piano implements Instrument {
	// 音を奏でるメソッドの実装
	public void play() {
		System.out.println("ポロン");
	}
}
