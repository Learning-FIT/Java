package oopAns;

// Foodクラスをテストするクラス
public class FoodTest {

	public static void main(String[] args) {
		Food f = new Food("りんご", 100);
		System.out.println(f.toString());
	}

}
