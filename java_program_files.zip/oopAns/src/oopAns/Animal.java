package oopAns;

// 動物を表す抽象クラス
public abstract class Animal {
	// 鳴き声を表示する抽象メソッド
	abstract void speak();
}
