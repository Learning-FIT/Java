package oopAns;

// 食品を表すクラス
public class Food {
	// 食品名と価格を保持するフィールド
	private String name;
	private int price;

	// toStringメソッドのオーバーライド
	// コメントアウトすれば、デフォルトのtoStringメソッドの機能を確認できます。
	public String toString() {
		return name + "：" + price + "円";
	}

	// コンストラクタ
	public Food(String name, int price) {
		this.name = name;
		this.price = price;
	}
}
