package oopAns;

// Pointクラスをテストするクラス
public class PointTest {

	public static void main(String[] args) {
		Point p1 = new Point(100, 200);
		Point p2 = new Point(100, 200);
		
		// 同一のオブジェクトを比較する
		System.out.println(p1.equals(p1));
		
		// フィールドの値が同じ別のオブジェクトを比較する
		System.out.println(p1.equals(p2));
	}

}
