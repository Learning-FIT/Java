package oopAns;

public class BoxingTest {
	// 引数objの文字列表現を画面に表示するメソッド
	public static void showObj(Object obj) {
		System.out.println(obj.toString());
	}

	// メインメソッド
	public static void main(String[] args) {
		// Objectを引数とするメソッドに値型のデータを渡す
		// ここでボクシングが行われます
		BoxingTest.showObj(123);
		
		// Intger型の変数に値型のデータを代入する
		// ここでボクシングが行われます
		Integer iobj = 456;
		System.out.println(iobj.toString());
		
		// int型の変数にInteger型のインスタンスを代入する
		// ここでアンボクシングが行われます
		int ival = iobj;
		System.out.println(ival);
	}

}
