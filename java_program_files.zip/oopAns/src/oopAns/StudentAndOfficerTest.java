package oopAns;

// StudentクラスとStudentOfficerクラスをテストするクラス
public class StudentAndOfficerTest {

	public static void main(String[] args) {
		// Studentクラスの機能を確認する
		Student yamada = new Student("山田太郎", 1);
		yamada.showGradeName();

		// StudentOfficerクラスの機能を確認する
		StudentOfficer suzuki = new StudentOfficer("鈴木花子", 3, "生徒会長");
		suzuki.showGradeName();
		suzuki.showPositionName();
	}

}
