package oopAns;

// 学生を表すクラス
public class Student {
	// 氏名と学年を保持するフィールド
	protected String name;
	protected int grade;

	// 学年と氏名を表示するメソッド
	public void showGradeName() {
		System.out.println(this.grade + "年生の" + this.name + "です。");
	}

	// コンストラクタ
	public Student(String name, int grade) {
		this.name = name;
		this.grade = grade;
	}
}
