package oopAns;

// Circleクラスをテストするクラス
public class CircleTest {
	
	public static void main(String[] args) {
		// Circleクラスのインスタンスを2つ生成する
		Circle c1 = new Circle(10);
		Circle c2 = new Circle(100);

		// 1つ目のインスタンスの面積を表示する
		System.out.println(c1.getArea());

		// 2つ目のインスタンスを10倍に拡大する
		c2.zoom(10);

		// 1つ目のインスタンスの面積を表示する
		// 半径が2倍されているので面積は100倍になる
		System.out.println(c2.getArea());
	}
	
}
