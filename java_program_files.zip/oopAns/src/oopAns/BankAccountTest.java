package oopAns;

// BankAccountクラスをテストするクラス
public class BankAccountTest {
	// フィールドの値を表示するメソッド
	public static void showBankAccout(BankAccount ba) {
		// ゲッタでフィールドの値を読み出す
		System.out.println("銀行名：" + ba.getBankName() + ", 番号：" + ba.getNumber()
			+ ", 名義：" + ba.getHolder() + ", 残高：" + ba.getBalance() + "円");
	}

	// メインメソッド
	public static void main(String[] args) {
		// BankAccountクラスのインスタンスを生成する
		BankAccount ba = new BankAccount("SEプラス銀行", "1234567", "山田太郎", 100000);

		// フィールドの値を表示する
		BankAccountTest.showBankAccout(ba);
		
		// セッタで適切な残高を書き込む
		ba.setBalance(150000);

		// フィールドの値を表示する
		BankAccountTest.showBankAccout(ba);

		// セッタで不適切な残高を書き込む
		ba.setBalance(-100000);
	}

}
