package oopAns;

// InstrumentTestインターフェイス、Pianoクラス、Guitarクラスをテストするクラス
public class InstrumentTest {

	public static void main(String[] args) {
		// 楽器の入れ物を用意する
		Instrument[] inst = new Instrument[5];
		
		// ピアノとギターを入れる
		inst[0] = new Piano();
		inst[1] = new Guitar();
		inst[2] = new Piano();
		inst[3] = new Piano();
		inst[4] = new Guitar();

		// 楽器を順番に奏でる
		for (int i = 0; i < inst.length; i++) {
			inst[i].play();
		}
	}
	
}
