package oopAns;

// ギターを表すクラス
public class Guitar implements Instrument {
	// 音を奏でるメソッドの実装
	public void play() {
		System.out.println("ジャーン");
	}
}
