package oopAns;

// 犬を表すクラス
public class Dog extends Animal {
	public void speak() {
		System.out.println("ワン");
	}
}
