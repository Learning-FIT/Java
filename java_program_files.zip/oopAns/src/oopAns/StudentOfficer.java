package oopAns;

// 生徒会役員を表すクラス
public class StudentOfficer extends Student {
	// 役職を保持するフィールド
	protected String position;

	// 役職と氏名を表示するメソッド
	public void showPositionName() {
		System.out.println(this.position + "の" + this.name + "です。");
	}

	// コンストラクタ
	public StudentOfficer(String name, int grade, String position) {
		super(name, grade);
		this.position = position;
	}
}
