package oopAns;

// Rectangleクラスをテストするクラス
public class RectangleTest {

	public static void main(String[] args) {
		// Rectangeクラスのインスタンスを生成する
		Rectangle r = new Rectangle(10, 5);

		// 現在の面積を表示する
		System.out.println(r.getArea());

		// 縦と横を2倍に拡大して、面積を表示する
		// 縦と横が2倍されているので面積は4倍になる
		r.zoom(2);
		System.out.println(r.getArea());

		// 縦を1倍、横を0.5倍に拡大して、面積を表示する
		// 縦が変わらず横が0.5倍されているので面積は半分になる
		r.zoom(1, 0.5);
		System.out.println(r.getArea());
	}

}
