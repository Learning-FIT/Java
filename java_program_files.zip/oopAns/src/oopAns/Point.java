package oopAns;

// 平面上の点を表すクラス
public class Point {
	// x座標とy座標を保持するフィールド
	private int x;
	private int y;

	// equalsメソッドのオーバーライド
	// コメントアウトすれば、デフォルトのequalsメソッドの機能を確認できます。
	public boolean equals(Object obj) {
		// 同一のインスタンスなら等しい
		if (this == obj) {
			return true;
		}
		
		// 同じクラスのオブジェクトで、フィールドの値がすべて同じなら等しい
		if (obj instanceof Point) {
			return this.x == ((Point)obj).x && this.y == ((Point)obj).y;
		}
		
		// どちらにも該当しなければ等しくない
		return false;
	}
	
	// コンストラクタ
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
