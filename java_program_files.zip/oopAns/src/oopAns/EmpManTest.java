package oopAns;

public class EmpManTest {

	public static void main(String[] args) {
		// Employeeクラスのインスタンスを生成して給与を求める
		Employee yamada = new Employee("山田太郎", 1000, 0);
		yamada.addHour(160);
		System.out.println(yamada.getName() + "の給与：" + yamada.getSalary() + "円");

		// Managerクラスのインスタンスを生成して給与を求める
		Manager suzuki = new Manager("鈴木花子", 1200, 0, 10000);
		suzuki.addHour(200);
		System.out.println(suzuki.getName() + "の給与：" + suzuki.getSalary() + "円");
	}

}
