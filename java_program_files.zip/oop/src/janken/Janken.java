/*
package janken;

import java.util.Scanner;

// メインメソッドを持つクラス
public class Janken {

}
*/