/*
package janken;

// プレイヤーを表す抽象クラス
public abstract class Player {

}
*/