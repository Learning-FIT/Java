/*
package janken;

// コンピュータを表すクラス
public class Computer extends Player {

}
*/