/*
package janken;

// 審判を表すクラス
public class Referee {

}
*/