/*
package janken;

import java.util.Scanner;

// ユーザーを表すクラス
public class User extends Player {

}
*/