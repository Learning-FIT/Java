package oop;

// 三角形を表すクラス
public class Triangle {
	// 底辺と高さを保持するフィールド
	private double bottom;
	private double height;
	
	// 面積を返すメソッド
	public double getArea() {
		return this.bottom * this.height / 2;
	}
	
	// 拡大するメソッド
	public void zoom(double rate) {
		this.bottom *= rate;
		this.height *= rate;
	}
	
	// コンストラクタ
	public Triangle(double bottom, double height) {
		this.bottom = bottom;
		this.height = height;
	}
}
