package oop;

// Triangleクラスをテストするクラス
public class TriangleTest {

	public static void main(String[] args) {
		// Triangleクラスのインスタンスを2つ生成する
		Triangle t1 = new Triangle(10, 5);
		Triangle t2 = new Triangle(20, 10);

		// 1つ目のインスタンスの面積を表示する
		System.out.println(t1.getArea());

		// 2つ目のインスタンスを2倍に拡大する
		t2.zoom(2);

		// 1つ目のインスタンスの面積を表示する
		// 底辺と高さが2倍されているので面積は4倍になる
		System.out.println(t2.getArea());
	}

}
