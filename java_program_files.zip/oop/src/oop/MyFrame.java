package oop;

import javax.swing.JFrame;

// シンプルなWindowsアプリのクラス
public class MyFrame extends JFrame {
	// コンストラクタだけを追加
	public MyFrame(String title, int width, int height) {
		this.setTitle(title);		
		this.setSize(width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);	
	}
}
