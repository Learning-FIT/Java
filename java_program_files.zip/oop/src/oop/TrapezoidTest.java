package oop;

// Trapezoidクラスをテストするクラス
public class TrapezoidTest {
	
	public static void main(String[] args) {

	}

}
