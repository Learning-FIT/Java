package oop;

// MyFrameクラスをテストするクラス
public class MyFrameTest {

	public static void main(String[] args) {
		// MyFrameクラスのインスタンスを生成する
		new MyFrame("サンプルプログラム", 400, 300);
	}
}
