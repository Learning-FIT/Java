package oop;

// Rectangleクラスをテストするクラス
public class RectangleTest {

	public static void main(String[] args) {

	}

}
