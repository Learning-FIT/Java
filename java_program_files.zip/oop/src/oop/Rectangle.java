package oop;

// 四角形形を表すクラス
public class Rectangle {
	// 縦と横を保持するフィールド
	private double vertical;
	private double horizontal;
	
	// 面積を返すメソッド
	public double getArea() {
		return this.vertical * this.horizontal;
	}
	
	// 縦と横をrate倍に拡大するメソッド
	
	// 縦をrateV倍、横をrateH倍に拡大するメソッド

	// コンストラクタ
	public Rectangle(double vertical, double horizontal) {
		this.vertical = vertical;
		this.horizontal = horizontal;
	}

}
