package oop;

// 台形を表すクラス
public class Trapezoid {
	// 上底、下底、高さを保持するフィールド
	private double top;
	private double bottom;
	private double height;
	
	// 面積を返すメソッド
	public double getArea() {
		return (this.top + this.bottom) * this.height / 2;
	}

	// 引数があるコンストラクタ

	// 引数がないコンストラクタ（デフォルトコンストラクタ）
}
