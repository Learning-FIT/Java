package basic;

import java.util.Scanner;

public class Bmi {

	public static void main(String[] args) {
		// 変数の宣言
		double height; // 身長（m）
		double weight; // 体重（kg）
		double bmi; // BMI

		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// データの入力
		System.out.print("身長（m）-->");
		height = scn.nextDouble();
		System.out.print("体重（kg）-->");
		weight = scn.nextDouble();

		// データの演算
		bmi = weight / height / height;

		// データの出力
		System.out.println("あなたのBMIは、" + bmi + "です。");

		// キー入力の終了処理
		scn.close();
	}

}

