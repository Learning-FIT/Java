package basic;

import java.util.Scanner;

public class AdultMethod {

	// 成人（adult）を判定するメソッド
	public static boolean isAdult(int age) {
		final int ADLUT_AGE = 18;
		return age >= ADLUT_AGE;
	}

	// メインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 年齢をキー入力する
		System.out.print("年齢-->");
		int age = scn.nextInt();

		// 判定結果を表示する
		if (AdultMethod.isAdult(age)) {
			System.out.println("成人です。");
		}
		else {
			System.out.println("未成年です。");
		}

		// キー入力の終了処理
		scn.close();
	}

}
