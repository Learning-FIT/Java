package basic;

import java.util.Scanner;

public class MonthIf {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 月の数字をキー入力する
		System.out.print("月の数字（1～12）-->");
		int month = scn.nextInt();

		// 月の数字に対応する英語を得る
		String english;
		if (month == 1) {
			english = "January";
		} else if (month == 2) {
			english = "February";
		} else if (month == 3) {
			english = "March";
		} else if (month == 4) {
			english = "April";
		} else if (month == 5) {
			english = "May";
		} else if (month == 6) {
			english = "June";
		} else if (month == 7) {
			english = "July";
		} else if (month == 8) {
			english = "August";
		} else if (month == 9) {
			english = "September";
		} else if (month == 10) {
			english = "October";
		} else if (month == 11) {
			english = "November";
		} else if (month == 12) {
			english = "December";
		} else {
			english = "1～12を入力してください。";
		}

		// 英語を表示する
		System.out.println(english);

		// キー入力の終了処理
		scn.close();
	}

}
