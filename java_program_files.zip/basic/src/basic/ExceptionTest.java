package basic;

import java.util.Scanner;

public class ExceptionTest {
	
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 2つの整数をキー入力する
		System.out.print("1つ目の整数-->");
		String s = scn.next();			// 文字列として入力して
		int a = Integer.parseInt(s);	// 整数に変換する
		System.out.print("2つ目の整数-->");
		s = scn.next();					// 文字列として入力して
		int b = Integer.parseInt(s);	// 整数に変換する

		// 除算を行う
		int ans = a / b;
		
		// 除算結果を表示する
		System.out.println("除算結果：" + ans);
		
		// キー入力の終了処理
		scn.close();
	}

}
