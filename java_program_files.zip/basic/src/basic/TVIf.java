package basic;

import java.util.Scanner;

public class TVIf {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// TVチャンネル番号をキー入力する
		System.out.print("TVチャンネル番号（1～8）-->");
		int channel = scn.nextInt();

		// TVチャンネル番号に対応する放送局を得る
		String station;
		if (channel == 1) {
			station = "NHK総合";
		} else if (channel == 2) {
			station = "NHK Eテレ";
		} else if (channel == 4) {
			station = "日本テレビ";
		} else if (channel == 5) {
			station = "テレビ朝日";
		} else if (channel == 6) {
			station = "TBS";
		} else if (channel == 7) {
			station = "テレビ東京";
		} else if (channel == 8) {
			station = "フジテレビ";
		} else {
			station = "放送局が割り当てられていません。";
		}

		// 放送局を表示する
		System.out.println(station);

		// キー入力の終了処理
		scn.close();
	}

}
