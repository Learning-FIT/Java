package basic;

import java.util.Scanner;

public class BmiMethod {
	// BMIを求めるメソッド
	public static double getBmi(double height, double weight) {
		double mHeight, bmi;

		mHeight = height / 100;
		bmi = weight / mHeight / mHeight;

		return bmi;
	}
	
	// メインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 身長と体重をキー入力する
		System.out.print("身長（cm）-->");
		double height = scn.nextDouble();
		System.out.print("体重（kg）-->");
		double weight = scn.nextDouble();

		// BMIを求めるメソッドを呼び出す
		double bmi = BmiMethod.getBmi(height, weight);

		// BMIの値を表示する
		System.out.println("あなたのBMIは、" + String.format("%.1f", bmi) + "です。");
		
		// キー入力の終了処理
		scn.close();
	}

}
