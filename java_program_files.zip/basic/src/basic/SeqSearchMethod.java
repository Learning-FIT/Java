package basic;

import java.util.Scanner;

public class SeqSearchMethod {

	// 線形探索（sequential search）を行うメソッド
	public static int seqSearch(int[] a, int x) {
		int pos = -1; // 見つかった位置の添字を初期化する

		for (int i = 0; i < a.length; i++) {
			if (a[i] == x) {
				pos = i; // 見つかった位置を設定する
				break;
			}
		}

		return pos; // 見つかった位置を返す
	}

	// メインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 初期値を持つ要素数10個の配列を宣言する
		int[] a = { 75, 67, 92, 53, 88, 74, 63, 58, 61, 82 };

		// 探索する値をキー入力する
		System.out.print("探索する値-->");
		int x = scn.nextInt();

		// 配列を線形探索する
		int pos = SeqSearchMethod.seqSearch(a, x);
		
		// 探索結果を表示する
		if (pos >= 0) {
			System.out.println(pos + "番目に見つかりました。");
		} else {
			System.out.println("見つかりません。");
		}

		// キー入力の終了処理
		scn.close();
	}

}
