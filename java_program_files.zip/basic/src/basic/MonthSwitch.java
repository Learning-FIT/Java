package basic;

import java.util.Scanner;

public class MonthSwitch {

	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);

		// 月の数字をキー入力する
		System.out.print("月の数字（1～12）-->");
		int month = scn.nextInt();

		// 月の数字に対応する英語を得る
		String english;
		switch (month) {
		case 1:
			english = "January";
			break;
		case 2:
			english = "February";
			break;
		case 3:
			english = "March";
			break;
		case 4:
			english = "April";
			break;
		case 5:
			english = "May";
			break;
		case 6:
			english = "June";
			break;
		case 7:
			english = "July";
			break;
		case 8:
			english = "August";
			break;
		case 9:
			english = "September";
			break;
		case 10:
			english = "October";
			break;
		case 11:
			english = "November";
			break;
		case 12:
			english = "December";
			break;
		default:
			english = "1～12を入力してください。";
			break;
		}

		// 英語を表示する
		System.out.println(english);

		// キー入力の終了処理
		scn.close();
	}

}
