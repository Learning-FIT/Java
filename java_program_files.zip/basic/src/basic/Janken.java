/*
package basic;

import java.util.Scanner;

public class Janken {
	
	// ユーザーの手を返すメソッド
	public static int getUserHand(Scanner scn) {
		// ここに処理を記述してください
		
	}
	
	// コンピュータの手を返すメソッド
	public static int getComputerHand() {
		// ここに処理を記述してください
		
	}
	
	// じゃんけんの結果を返すメソッド
	public static String judge(int user, int computer) {
		// ここに処理を記述してください
		
	}
	
	// じゃんけんの結果を表示するメソッド
	public static void showResult(String result) {
		// ここに処理を記述してください
		
	}
	
	// 他のメソッドを連携させるメインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);
		
		// メソッドを連携させじゃんけんを行い
		// あいこの場合は、再勝負とする
		int user, computer;
		String result;
		do {
			user = Janken.getUserHand(scn);
			computer = Janken.getComputerHand();
			result = Janken.judge(user, computer);
			Janken.showResult(result);
		} while (user == computer);

		// キー入力の終了処理
		scn.close();
	}

}
*/