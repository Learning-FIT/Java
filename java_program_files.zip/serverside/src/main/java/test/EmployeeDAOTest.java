package test;

import java.util.List;
import java.util.Scanner;

import dao.EmployeeDAO;
import dto.Employee;

// EmployeeDAOをテストするプログラム
public class EmployeeDAOTest {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		
		// 検索する番号と氏名をキー入力する
		System.out.print("番号-->");
		String number = scn.next();
		System.out.print("氏名-->");
		String name = scn.next();
		
		// EmployeeDAOのインスタンスを生成する
		EmployeeDAO dao = new EmployeeDAO();
		
		// EmployeeDAOのselectメソッドを使って検索を行う
		Employee emp = new Employee(number, name);
		List<Employee> empList = dao.select(emp);
		
		// 検索結果を表示する
		for (Employee e : empList) {
			System.out.println(e.getNumber() + ", " + e.getName());
		}
		
		scn.close();
	}

}
