package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dto.Employee;

// Employeeテーブルを操作するDAO
public class EmployeeDAO {
	// Employeeテーブルを検索するメソッド
	public List<Employee> select(Employee emp) {
		// 結果セットを格納するコレクション
		List<Employee> empList = new ArrayList<Employee>();

		// データベースに接続と切断を行うオブジェクト
		Connection conn = null;

		try {
			// JDBCドライバを読み込む
			Class.forName("com.mysql.cj.jdbc.Driver");

			// データベースに接続する
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/serverside?"
					+ "characterEncoding=utf8&useSSL=false&serverTimezone=GMT%2B9&rewriteBatchedStatements=true",
					"root", "password");

			// SQL文を作成する
			String sql = "SELECT number, name FROM EMPLOYEE WHERE number LIKE ? AND name LIKE ?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, "%" + emp.getNumber() + "%");
			pStmt.setString(2, "%" + emp.getName() + "%");

			// SQL文を実行して検索結果を取得する
			ResultSet rs = pStmt.executeQuery();

			// 検索結果をコレクションに格納する
			while (rs.next()) {
				Employee e = new Employee(rs.getString("number"), rs.getString("name"));
				empList.add(e);
			}

			// 検索結果が格納されたコレクションを返す
			return empList;
		}
		catch (Exception e) {
			// 例外処理
			e.printStackTrace();
			return null;
		}
		finally {
			// データベースを切断する
			if (conn != null) {
				try {
					conn.close();
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

}
