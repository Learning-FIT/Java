package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dto.Employee;

/**
 * Servlet implementation class SesScopeServletA
 */
@WebServlet("/SesScopeServletA")
public class SesScopeServletA extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// リクエストパラメータの文字コードを設定する
		request.setCharacterEncoding("UTF-8");

		// リクエストパラメータを取得する
		String number = request.getParameter("number");
		String name = request.getParameter("name");

		// セッションオブジェクトを取得する
		HttpSession session = request.getSession();

		// セッションスコープにデータを格納する
		session.setAttribute("emp", new Employee(number, name));

		// SesScopeServletBにリダイレクトする
		response.sendRedirect("/serverside/SesScopeServletB");
	}

}
