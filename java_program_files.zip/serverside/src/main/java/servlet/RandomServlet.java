package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RandomServlet
 */
@WebServlet("/RandomServlet")
public class RandomServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1～3の乱数を生成する
		int r = (int) (Math.random() * 3) + 1;

		// HTTPレスポンスヘッダにHTMLであることとUTF-8であることを設定する
		response.setContentType("text/html; charset=UTF-8");

		// HTTPレスポンンスに書き込む機能を持つオブジェクトに取得する
		PrintWriter out = response.getWriter();

		// HTTPレスポンスにHTMLを書き込む（任意のHTMLを書き込む）
		out.println("<html>");
		out.println("<head>");
		out.println("<title>1～3の乱数を生成する</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<p>生成された乱数は、" + r + "です。</p>");
		out.println("</body>");
		out.println("</html>");
	}

}
