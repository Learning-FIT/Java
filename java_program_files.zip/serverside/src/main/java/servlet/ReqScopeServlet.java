package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.Employee;
/**
 * Servlet implementation class ReqScopeServlet
 */
@WebServlet("/ReqScopeServlet")
public class ReqScopeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// リクエストパラメータの文字コードを設定する
		request.setCharacterEncoding("UTF-8");

		// リクエストパラメータを取得する
		String number = request.getParameter("number");
		String name = request.getParameter("name");

		// リクエストスコープにデータを格納する
		request.setAttribute("emp", new Employee(number, name));

		// req_scope.jspにフォワードする
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/req_scope.jsp");
		dispatcher.forward(request, response);
	}

}
