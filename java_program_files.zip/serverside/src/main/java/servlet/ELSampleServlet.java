package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ELSampleServlet
 */
@WebServlet("/ELSampleServlet")
public class ELSampleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// リクエストスコープにデータを格納する
		request.setAttribute("data1", "これは、リクエストスコープに格納されたデータです。");

		// セッションスコープにデータを格納する
		HttpSession session = request.getSession();
		session.setAttribute("data2", "これは、セッションスコープに格納されたデータです。");

		// el_sample.jspにフォワードする
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/el_sample.jsp");
		dispatcher.forward(request, response);
	}

}
