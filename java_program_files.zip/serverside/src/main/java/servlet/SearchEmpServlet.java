package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SearchEmpServlet
 */
@WebServlet("/SearchEmpServlet")
public class SearchEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// リクエストパラメータの文字コードを設定する
		// ここにプログラムを追加してください

		// リクエストパラメータを取得する
		// ここにプログラムを追加してください
		
		// データベースを検索して結果をリクエストスコープに格納する
		// ここにプログラムを追加してください

		// search_emp_result.jspにフォワードする
		// ここにプログラムを追加してください

	}

}
