package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class JankenServlet
 */
@WebServlet("/JankenServlet")
public class JankenServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// リクエストパラメータのエンコーディングを設定する
		request.setCharacterEncoding("UTF-8");

		// リクエストパラメータを取得する
		String playerName = request.getParameter("player");
		int playerHand = Integer.parseInt(request.getParameter("hand"));

		// サーバーが乱数で手を選ぶ
		int serverHand = (int) (Math.random() * 3) + 1;

		// じゃんけんの勝敗を判定する
		String judge;
		if (playerHand == serverHand) {
			judge = "あいこです。";
		} else if ((playerHand - serverHand + 3) % 3 == 2) {
			judge = playerName + "さんの勝ちです。";
		} else {
			judge = playerName + "さんの負けです。";
		}

		// HTTPレスポンスヘッダのコンテンツタイプにHTMLであることとUTF-8であることを設定する
		response.setContentType("text/html; charset=UTF-8");

		// HTTPレスポンンスに書き込む機能を持つオブジェクトに取得する
		PrintWriter out = response.getWriter();

		// HTTPレスポンスにHTMLを書き込む（任意のHTMLを書き込む）
		String[] hand = { "", "グー", "チョキ", "パー" };
		out.println("<html><head><title>じゃんけんの結果</title></head><body>");
		out.println("<p>" + playerName + "さんの手は、" + hand[playerHand] + "</p>");
		out.println("<p>サーバーの手は、" + hand[serverHand] + "</p>");
		out.println("<p>" + judge + "</p>");
		out.println("</body></html>");
	}

}
