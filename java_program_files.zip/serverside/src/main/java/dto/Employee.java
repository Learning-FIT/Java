package dto;

import java.io.Serializable;

// EmployeeテーブルのDTO（JavaBeans形式）
public class Employee implements Serializable {
	private String number;	// number列
	private String name;	// name列

	// numberのゲッタ
	public String getNumber() {
		return number;
	}

	// numberのセッタ
	public void setNumber(String number) {
		this.number = number;
	}

	// nameのゲッタ
	public String getName() {
		return name;
	}

	// nameのセッタ
	public void setName(String name) {
		this.name = name;
	}

	// 引数がないコンストラクタ
	public Employee() {
		this("", "");
	}

	// 引数があるコンストラクタ
	public Employee(String number, String name) {
		this.number = number;
		this.name = name;
	}
}
