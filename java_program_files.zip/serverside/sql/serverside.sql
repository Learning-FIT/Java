CREATE TABLE Employee (number CHAR(4) PRIMARY KEY, name VARCHAR(40));
INSERT INTO Employee VALUES('0001', '山田太郎');
INSERT INTO Employee VALUES('0002', '鈴木花子');
INSERT INTO Employee VALUES('0003', '佐藤三郎');
SELECT * FROM Employee;
