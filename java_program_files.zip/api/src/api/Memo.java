/*
package api;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Memo {
	// memo.txtの内容をリストに読み出すメソッド
	public static void readFile(List<String> memoList) {

	}
	
	// リストの内容をmemo.txtに書き込むメソッド
	public static void writeFile(List<String> memoList) {

	}
	
	// リストの内容を一覧表示するメソッド
	public static void showList(List<String> memoList) {

	}
	
	// 現在の日時を"2022/01/07 10:45:06"という形式の文字列で返すメソッド
	public static String getDate() {

	}
	
	// リストにメモを登録するメソッド
	public static void registList(List<String> memoList, Scanner scn) {

	}
	
	// リストからメモを削除するメソッド
	public static void deleteList(List<String> memoList, Scanner scn) {

	}
	
	// メインメソッド
	public static void main(String[] args) {
		// キー入力の準備処理
		Scanner scn = new Scanner(System.in);
		
		// 文字列を格納する空のリストを作成します。
		List<String> memoList = new ArrayList<String>();
		
		// memo.txtの内容をリストに読み出します
		Memo.readFile(memoList);
		
		// メニュー項目に合わせた処理を行います
		boolean contFlag = true;
		while (contFlag) {
			System.out.print("表示：S, 登録：R, 削除：D, 終了：Q -->");
			String item = scn.next();
			switch (item) {
			case "S":
			case "s":
				Memo.showList(memoList);
				break;
			case "R":
			case "r":
				Memo.registList(memoList, scn);
				break;
			case "D":
			case "d":
				Memo.deleteList(memoList, scn);
				break;
			case "Q":
			case "q":
				System.out.println("終了しました。");
				contFlag = false;
				break;
			}
		}
		
		// リストの内容をmemo.txtに書き込みます
		Memo.writeFile(memoList);

		// キー入力の終了処理
		scn.close();
	}

}
*/