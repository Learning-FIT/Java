package api;

// StringBuilderクラスの様々なメソッドの機能を確認するプログラム
public class StringBuilderTest {

	public static void main(String[] args) {
		// StringBuilderクラスのインスタンスを生成する
		StringBuilder sb = new StringBuilder("hello");

		// lengthメソッドを使って文字列sbの長さを求める
		System.out.println(sb.length());
		
		// charAtメソッドを使ってsbの先頭の1文字を取得する
		
		// indexOfメソッドを使ってsbから"l"を検索する
		
		// appendメソッドを使ってsbの末尾に", world"を追加する
		
		// deleteメソッドを使ってsbの0文字目から7文字目未満までを削除する
		
		// insertメソッドを使ってsbの0文字目に"Hi, "を挿入する

		// replaceメソッドを使ってsbの4文字目から9文字目未満を"Java"に置き換える

	}

}
