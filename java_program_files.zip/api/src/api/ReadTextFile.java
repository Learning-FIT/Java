package api;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

//テキストファイルから1行ずつ読み出すプログラム
public class ReadTextFile {

	public static void main(String[] args) {
		try {
			// ファイル読み出しの準備処理
			File file = new File("sample.txt");
			if (!file.exists()) {
				// ファイルが存在しない場合は終了します
				System.out.println("ファイルがありません。");
				return;
			}
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			
			// ファイルから1行ずつ読み出します
			String s;
			while ((s = br.readLine()) != null) {
				System.out.println(s);
			}
			
			// ファイル読み出しの終了処理
			br.close();
			fr.close();
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		} 
	}

}
