package api;

import java.util.Calendar;
import java.util.Date;

// DateクラスとCalendarクラスの機能を確認するプログラム
public class DateCalTest {

	public static void main(String[] args) {
		// Dateクラスのインスタンスを生成して現在日時を取得します
		Date now = new Date();

		// Calendarクラスのインスタンスを取得して現在日時を設定します
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		
		// 現在日時を、年、月、日、曜日、時、分、秒に分けて取得します
		// 月は、1月～12月が、0～11で得られます
		// 曜日は、日曜日～土曜日が、1～7で得られます
		System.out.println("年：" + cal.get(Calendar.YEAR));
		System.out.println("月：" + cal.get(Calendar.MONTH));
		System.out.println("日：" + cal.get(Calendar.DAY_OF_MONTH));
		System.out.println("曜日：" + cal.get(Calendar.DAY_OF_WEEK));
		System.out.println("時：" + cal.get(Calendar.HOUR_OF_DAY));
		System.out.println("分：" + cal.get(Calendar.MINUTE));
		System.out.println("秒：" + cal.get(Calendar.SECOND));
	}

}
