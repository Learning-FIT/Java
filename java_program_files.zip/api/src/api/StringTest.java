package api;

// Stringクラスの様々なメソッドの機能を確認するプログラム
public class StringTest {

	public static void main(String[] args) {
		// lengthメソッドを使って"hello"の長さを求める
		String s = "hello";
		System.out.println(s.length());

		// equalsメソッドを使ってsと"hello"を比較する

		// equalsメソッドを使ってsと"HELLO"を比較する
		
		// charAtメソッドを使ってsの先頭の1文字を取得する
		
		// indexOfメソッドを使ってsから"l"を検索する
		
		// toUpperCaseメソッドを使ってsをすべて大文字に変換した新たな文字列tを得る
		
		// replaceメソッドを使ってsの中にある'h'を'H'に置き換えた新たな文字列uを得る
		
		// staticなformatメソッドを使って10進数の15を2桁の16進数に（英字にA～Fを使う）
		// 置き換えた新たな文字列vを得る

	}

}
