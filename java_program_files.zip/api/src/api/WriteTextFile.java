package api;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

// テキストファイルに1行ずつ書き込むプログラム
public class WriteTextFile {

	public static void main(String[] args) {
		try {
			// ファイル書き込みの準備処理
			File file = new File("sample.txt");
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
		
			// ファイルに1行ずつ書き込みます
			bw.write("apple");
			bw.newLine();
			bw.write("orange");
			bw.newLine();
			bw.write("banana");
			bw.newLine();
		
			// ファイル書き込みの終了処理
			bw.close();
			fw.close();
			System.out.println("ファイルに書き込みました。");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
